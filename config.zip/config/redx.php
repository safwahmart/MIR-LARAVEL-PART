<?php

return [
    "sandbox"      => env("REDX_SANDBOX", true),
    "access_token" => env("REDX_ACCESS_TOKEN", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4MDA5NTUiLCJpYXQiOjE2ODk4NDYwMzksImlzcyI6Imo1Q0tuTThtYTBQNExUajdBZGRsZVNrZTg4cnlmYUFyIiwic2hvcF9pZCI6ODAwOTU1LCJ1c2VyX2lkIjoxODU5NDQ3fQ.4mZfLtb2KELRe2dcyrtC6JO_QFiCOCRznJTkgmTWxBs"),
];
